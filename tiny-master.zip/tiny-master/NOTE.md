To make sure users do not get distracted by the name of code files, I have
renamed some files to simpler forms. This is a file to keep track of name
changes.


- `scripts/hybrid_trires_limit30_hardmine_res101_normalscale_restdouble.m` <- `scripts/hr_res101.m`

- `cluster_rects.m` <- `cluster_rects_noresz.m`.

- `cnn_get_batch_hardmine.m` <- `cnn_get_batch_logistic_trires_limit30_hardmine_negborder.m`.

- `cnn_widerface_test_AB.m` <- `cnn_widerface_test_with_zoom_AB_negborder.m`.

- `data/widerface/RefBox_N25_scaled.mat` <- `data/widerface/RefBox_NoResize_N25_scaled.mat`. 
- `data/widerface/RefBox_N25.mat` <- 'data/widerface/RefBox_NoResize_N25_min10x10_maxInfxInf.mat`

- `cnn_widerface_eval.m` <- `cnn_widerface_eval_new.m`

