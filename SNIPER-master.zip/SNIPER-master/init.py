import sys
sys.path.insert(0,'lib')
sys.path.insert(0,'SNIPER-mxnet/python')
