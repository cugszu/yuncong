"""
Bunch of snippets to help with various processing tasks
"""